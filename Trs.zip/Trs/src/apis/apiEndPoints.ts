export const endPoint = {
    categories :'categories',
    videos:'videos',
    classes:'classes',
    gov:'gov',
    subjectsbyclass:'subjects-by-class',
    chapters:'chapters',
    winner:'winner',
    comment:'comment',
}