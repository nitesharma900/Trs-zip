module.exports = {
  preset: 'react-native',
};
